#include "UiLayer.h"
#include "define.h"
#include "GameWorld.h"
#include "Build.h"
#include "Player.h"
#include "StateLayer.h"

bool UiLayer::IsTouch = false;
bool UiLayer::GameOver = false;
long UiLayer::IntScore = 0;


UiLayer::UiLayer()
{
	CCLOG("UiLayer Created");
	for (int i = 0; i < 5; i++)
	{
		this->_bg[i]				= nullptr;
		this->_walk[i]				= nullptr;
		this->_build[i]._builddown	= nullptr;
		this->_build[i]._buildup	= nullptr;
	}

	this->_score	= nullptr;
	this->_partical	= nullptr;

	this->_Player	= nullptr;
	this->_begin	= nullptr;
	this->_title	= nullptr;
	this->_readly	= nullptr;

	this->_restart	= nullptr;
	this->_over		= nullptr;
}

UiLayer::~UiLayer()
{
	CCLOG("UiLayer Destoryed");
}

bool UiLayer::init()
{
	bool ret = false;
	
	do
	{
		CC_BREAK_IF(!Layer::init());

// ��Ϸ�����ز�
	// ��ʼ��bg  walk build
		bool _initbg = false;
		for (int i = 0; i < 5; i++)
		{
	// bg
			
			if(GW::GameHour <= 6 || GW::GameHour >= 21)
				this->_bg[i] = Sprite::createWithSpriteFrameName("bg_night.png");
			else
				this->_bg[i] = Sprite::createWithSpriteFrameName("bg_day.png");
			CC_BREAK_IF(!_bg[i]);
			this->_bg[i]->setAnchorPoint(ccp(0.0f, 0.0f));
			this->_bg[i]->setPosition(DIN()->getWinSize().width/BGJG * (float)i, 0.0f);
			this->_bg[i]->getTexture()->setAliasTexParameters();
			this->addChild(this->_bg[i], 0);

	// walk
			this->_walk[i] = Sprite::createWithSpriteFrameName("land.png");
			CC_BREAK_IF(!_walk[i]);
			this->_walk[i]->setAnchorPoint(ccp(0.0f, 0.0f));
			this->_walk[i]->setPosition(DIN()->getWinSize().width / WALKJG * (float)i, 0.0f);
			this->_walk[i]->getTexture()->setAliasTexParameters();
			this->addChild(this->_walk[i], 1);

	// build
			this->_build[i]._builddown = Build::create(Vec2((DIN()->getWinSize().width / BUILDJG) * ((float)i + 1.0f), 0.0f));
			CC_BREAK_IF(!this->_build[i]._builddown);

			this->_build[i]._buildup = Build::create(Vec2((DIN()->getWinSize().width / BUILDJG) * ((float)i + 1.0f), DIN()->getWinSize().height), true);
			CC_BREAK_IF(!this->_build[i]._buildup);

			this->addChild(this->_build[i]._builddown, 2);
			this->addChild(this->_build[i]._buildup, 2);

			Build::RandomPosY(&this->_build[i],25.0f);

			this->_build[i]._builddown->setPositionX(_build[i]._builddown->getPositionX() + DIN()->getWinSize().width);
			this->_build[i]._buildup->setPositionX(_build[i]._buildup->getPositionX() + DIN()->getWinSize().width);

	// ȷ�����ж���ʼ��
			if (i == 4)
				_initbg = true;
		}

	// build walk bg �Ƿ�ȫ����ʼ���ж�
		CC_BREAK_IF(!_initbg);

	// ����
		this->_score = Label::createWithBMFont("font2.fnt","0");
		CC_BREAK_IF(!_score);
		this->_score->setPosition(GW::GetWinCenter());
		this->_score->setPositionY(GW::GetWinMaxSize().y - _score->getContentSize().height);
		this->_score->setVisible(false);
		this->addChild(_score, 6);

// ��Ϸ��ʼ�ز�
	// ��һ�ȡ
		this->_Player = GetMainPlayer();
		CC_BREAK_IF(!this->_Player);
		GetMainPlayer()->setAnchorPoint(ccp(0.13f, 0.5f));
		this->addChild(this->_Player, 4);
		this->_Player->setPosition(-100.0f, DIN()->getWinSize().height / 2.0f);
		this->_Player->ChangeAnimate();
		this->_Player->runAction(EaseExponentialOut::create(MoveTo::create(0.5f, Vec2(this->_Player->getContentSize().width*2, DIN()->getWinSize().height / 2.0f))));

	// ��Ч
		this->_partical = ParticleMeteor::create();
		CC_BREAK_IF(!_partical);
		GetMainPlayer()->_partical = this->_partical;
		this->_partical->setScale(0.3f);
		this->_partical->setColor(Color3B::GREEN);
		this->_partical->setPosition(Vec2(this->_Player->getContentSize().width * 1.5f, DIN()->getWinSize().height / 2.0f));
		this->_partical->setGravity(Vec2(-2300.0f, 0.0f));
		this->_partical->setStartColor(GetMainPlayer()->getTypeAnimate() == RedMode ? Color4F::RED  : GetMainPlayer()->getTypeAnimate() == BlueMode ? Color4F(173,216,230,255) : Color4F::ORANGE);
		this->_partical->setAngleVar(0.0f);
		this->addChild(_partical, 3);
	
	// ���ñ���
		this->_title = Sprite::createWithSpriteFrameName("title.png");
		CC_BREAK_IF(!_title);
		this->_title->setScale(2.0f);
		this->_title->setPosition(GW::GetWinCenter());
		this->_title->setPositionY(_title->getPositionY() + DIN()->getWinSize().height/3);
		this->addChild(_title, 4);

	// ���ÿ�ʼ���
		this->_begin = Sprite::createWithSpriteFrameName("tutorial.png");
		CC_BREAK_IF(!this->_begin);
		this->_begin->setPosition(GW::GetWinCenter());
		this->_begin->setScale(1.0f);
		this->addChild(this->_begin, 4);

	// ����Readly
		this->_readly = Sprite::createWithSpriteFrameName("text_ready.png");
		CC_BREAK_IF(!this->_readly);
		this->_readly->setScale(0.65f);
		this->_readly->setRotation(35.0f);
		this->_readly->setPosition(this->_begin->getPositionX() + this->_begin->getContentSize().width /2.0f , this->_begin->getPositionY() + this->_begin->getContentSize().height / 2.0f);
		this->addChild(this->_readly, 5);
		this->_readly->runAction(RepeatForever::create(Sequence::createWithTwoActions(EaseExponentialInOut::create(ScaleTo::create(0.5f, 0.8f)),EaseExponentialInOut::create(ScaleTo::create(0.5f, 0.65f)))));


// ��Ϸ�����ز�

	// ���ý�������
		this->_over = Sprite::createWithSpriteFrameName("text_game_over.png");
		CC_BREAK_IF(!_over);
		this->_over->setScale(1.3f);
		this->_over->setPosition(GW::GetWinCenter());
		this->_over->setVisible(false);
		this->addChild(_over, 5);

	// ���ð�ť
		this->_restart = Button::create("button_play.png", "button_play.png", "button_play.png");
		CC_BREAK_IF(!_restart);
		this->_restart->setVisible(false);
		this->_restart->addTouchEventListener(CC_CALLBACK_2(UiLayer::ButtonOver, this));
		this->addChild(_restart, 5);		

		AudioEngine::play2d("background.ogg", true);

	// ������Ϸ��ѭ��
		schedule(CC_CALLBACK_1(UiLayer::BeginUpdate, this), 0.0f, "MyUiLayerBeginUpdate");

		ret = true;

	} while (0);

	return ret;
}

void UiLayer::update(float df)
{
	// ѭ�������ܶ�
	for (int i = 0; i < 5; i++)
	{
		for (float j = 0.0f; j < GW::GameSpeed; j += 0.1f)
		{
			// bg
			if(this->_bg[i] != nullptr)
				if (this->_bg[i]->getPositionX() < -DIN()->getWinSize().width / BGJG)
				{
					this->_bg[i]->setPositionX(DIN()->getWinSize().width);
				}
				else
				{
					this->_bg[i]->setPositionX(this->_bg[i]->getPositionX() - 0.1f);
				}

			// walk
			if(this->_walk[i] != nullptr)
				if (this->_walk[i]->getPositionX() < -DIN()->getWinSize().width / WALKJG)
				{
					this->_walk[i]->setPositionX(DIN()->getWinSize().width);
				}
				else
				{
					this->_walk[i]->setPositionX(this->_walk[i]->getPositionX() - 0.1f);
				}

			// build
			if (this->_build[i]._builddown != nullptr && this->_build[i]._buildup != nullptr)
			{
				if (this->_build[i]._buildup->getPositionX() < -DIN()->getWinSize().width / BUILDJG)
				{
					Build::RandomPosY(&this->_build[i],DIN()->getWinSize().height /7.0f);
				}
				this->_build[i]._builddown->update();
				if (this->_build[i]._buildup->update())
				{
					this->_build[i]._isOver = false;
				}
			}
		}

		// �ж���������
		if ((_build[i]._builddown->getBoundingBox().intersectsRect(_Player->getBoundingBox())))
		{
			GameOver = true;
			goto end;
		}
		else if ((_build[i]._buildup->getBoundingBox().intersectsRect(_Player->getBoundingBox())))
		{
			GameOver = true;
			goto end;
		}
		else if(GetMainPlayer() && this->_walk[0])
		{
			if (GetMainPlayer()->getPositionY() <= this->_walk[0]->getContentSize().height + GetMainPlayer()->getContentSize().height / 2.0f)
			{
				GameOver = true;
				goto end;
			}
		}

		// ���ӷ���
		if (GetMainPlayer())
		{
			if (_build[i]._builddown->getPositionX() + _build[i]._builddown->getContentSize().width / 2.0f <
				GetMainPlayer()->getPositionX() - GetMainPlayer()->getContentSize().width / 2.0f)
			{
				if (_build[i]._isOver == false && GetMainPlayer()->getIsDead() == false)
				{
					_build[i]._isOver = true;
					IntScore ++;
					AudioEngine::play2d("upgrade.mp3");
					this->_score->setString(std::to_string(IntScore));
					this->_score->stopAllActions();
					this->_score->setScale(1.0f);
					this->_score->runAction(Sequence::createWithTwoActions(ScaleTo::create(0.08f,1.95f), ScaleTo::create(0.08f,1.0f)));
				}
			}
		}
	}

end:
	if (GameOver == true)
	{
		AudioEngine::pauseAll();
		AudioEngine::stopAll();

		AudioEngine::play2d("sfx_hit.mp3");

		this->runAction(Sequence::createWithTwoActions(DelayTime::create(0.4f), CallFunc::create([&]() {AudioEngine::play2d("sfx_die.mp3"); })));

		schedule(CC_CALLBACK_1(UiLayer::EndUpdate, this), 0.0f, "MyUiLayerEndUpdate");

		unscheduleUpdate();
		unschedule("MyUiLayerTimeUpdate");
	}
	return;
}

void UiLayer::BeginUpdate(float df)
{	
	if (!this->_Player)
	{
		CCLOG("UiLayer::_Player is nullptr");
	}

	// ��ʼ��λ��
	for (int i = 0; i < 5; i++)
	{
		for (float j = 0.0f; j < GW::GameSpeed; j += 0.1f)
		{
			// bg
			if (this->_bg[i] != nullptr)
				if (this->_bg[i]->getPositionX() < -DIN()->getWinSize().width / BGJG)
				{
					this->_bg[i]->setPositionX(DIN()->getWinSize().width);
				}
				else
				{
					this->_bg[i]->setPositionX(this->_bg[i]->getPositionX() - 0.1f);
				}

			// walk
			if (this->_walk[i] != nullptr)
				if (this->_walk[i]->getPositionX() < -DIN()->getWinSize().width / WALKJG)
				{
					this->_walk[i]->setPositionX(DIN()->getWinSize().width);
				}
				else
				{
					this->_walk[i]->setPositionX(this->_walk[i]->getPositionX() - 0.1f);
				}
		}
	}

	IntScore = 0;

	// ��������
	if (UiLayer::IsTouch == true)
	{
		if (_title)
			_title->setVisible(false);
		if (_begin)
			_begin->setVisible(false);
		if (_readly)
			_readly->setVisible(false);
		if (_score)
			_score->setVisible(true);

		this->unschedule("MyUiLayerBeginUpdate");

		this->scheduleUpdate();
		this->schedule(CC_CALLBACK_1(UiLayer::TimeUpdate, this), 1.0f, "MyUiLayerTimeUpdate");

		if (GetMainPlayer())
		{
			GetMainPlayer()->setIsInit(true);
			GetMainPlayer()->setIsDead(false);
			GetMainPlayer()->ChangeAnimate();
		}
	}

}

void UiLayer::EndUpdate(float df)
{
	if (GetMainPlayer())
	{
		if (GetMainPlayer()->getPositionY() < -GetMainPlayer()->getContentSize().height / 2.0f)
		{
			unschedule("MyUiLayerEndUpdate");
			// ���ð�ťλ��
			if (_over)
			{
				this->_over->stopAllActions();
				this->_over->setPositionY(GW::GetWinMaxSize().y * 2);
				this->_over->setVisible(true);
				this->_over->runAction(EaseExponentialOut::create(MoveTo::create(1.5f, Vec2(GW::GetWinCenter().x, GW::GetWinMaxSize().y / 2.0f * 1.5f))));
			}

			if (_score)
			{
				this->_score->stopAllActions();
				this->_score->setScale(1.8f);
				this->_score->setPositionY(GW::GetWinMaxSize().y * 2);
				this->_score->runAction(EaseExponentialOut::create(MoveTo::create(1.5f, Vec2(GW::GetWinCenter().x, GW::GetWinMaxSize().y / 2.0f * 1.5f - (_over->getContentSize().height / 2.0f + (_score->getContentSize().height / 2.0f * 1.8f))))));
			}

			if (_restart)
			{
				this->_restart->stopAllActions();
				this->_restart->setPosition(Vec2(this->_score->getPosition()));
				this->_restart->setPositionY(this->_restart->getPositionY() - _score->getContentSize().height / 2.0f * 1.8f);
				this->_restart->runAction(EaseExponentialOut::create(MoveTo::create(1.5f, Vec2(GW::GetWinCenter().x, GW::GetWinCenter().y))));
				this->_restart->setVisible(true);
			}

			return;
		}
		GetMainPlayer()->Dead();
	}
}

void UiLayer::ButtonOver(Ref* pSender, Widget::TouchEventType type)
{
	if (type == Widget::TouchEventType::ENDED)
	{
		AudioEngine::play2d("cancelclick.mp3");

		GetMainPlayer()->Restart();

		UiLayer::IsTouch = false;
		StateLayer::IsFly = false;
		UiLayer::GameOver = false;
		UiLayer::IntScore = 0;
		GameWorld::GameSpeed = 3.0f;

		for (int i = 0; i < 5; i++)
		{
			if (this->_build[i]._builddown != nullptr && this->_build[i]._buildup != nullptr)
			{

				this->_build[i]._builddown->setPosition(Vec2((DIN()->getWinSize().width / BUILDJG) * ((float)i + 1.0f), 0.0f));
				this->_build[i]._buildup->setPosition(Vec2((DIN()->getWinSize().width / BUILDJG) * ((float)i + 1.0f), DIN()->getWinSize().height));

				Build::RandomPosY(&this->_build[i], DIN()->getWinSize().height / 7.0f);
				this->_build[i]._isOver = false;

				this->_build[i]._builddown->setPositionX(_build[i]._builddown->getPositionX() + DIN()->getWinSize().width);
				this->_build[i]._buildup->setPositionX(_build[i]._buildup->getPositionX() + DIN()->getWinSize().width);
			}
		}

		if (GetMainPlayer())
		{
			GMPL()->setIsInit(false);
			GMPL()->setIsDead(false);
			GMPL()->stopAllActions();
			GMPL()->setRotation(0.0f);
			GMPL()->setPosition(-100.0f, DIN()->getWinSize().height / 2.0f);
			GMPL()->ChangeAnimate();
			GMPL()->runAction(EaseExponentialOut::create(MoveTo::create(0.5f, Vec2(this->_Player->getContentSize().width * 2, DIN()->getWinSize().height / 2.0f))));
		}

		if (_over)
			this->_over->setVisible(false);

		if (_restart)
			this->_restart->setVisible(false);

		if (_score)
		{
			this->_score->stopAllActions();
			this->_score->setScale(1.0f);
			this->_score->setString(std::to_string(UiLayer::IntScore));
			this->_score->setPosition(GW::GetWinCenter());
			this->_score->setPositionY(GW::GetWinMaxSize().y - _score->getContentSize().height);
			this->_score->setVisible(false);
		}

		if (_title)
			_title->setVisible(true);
		if (_begin)
			_begin->setVisible(true);
		if (_readly)
			_readly->setVisible(true);
		if (_score)
			_score->setVisible(false);

		AudioEngine::play2d("background.ogg", true);

		schedule(CC_CALLBACK_1(UiLayer::BeginUpdate, this), 0.0f, "MyUiLayerBeginUpdate");
	}
}

void UiLayer::TimeUpdate(float df)
{
	GW::GameSpeed += 0.1f;
}
