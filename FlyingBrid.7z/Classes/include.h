#include <cocos2d.h>
#include <ui/CocosGUI.h>
#include <ui/UILoadingBar.h>
#include <AudioEngine.h>
#include <string>
#include <sstream>
#include <fstream>

USING_NS_CC;
using namespace ui;