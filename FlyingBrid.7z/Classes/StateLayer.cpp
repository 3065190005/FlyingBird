#include "StateLayer.h"
#include "UiLayer.h"
#include "GameWorld.h"
#include "Player.h"

bool StateLayer::IsFly = false;


StateLayer::StateLayer()
{
	CCLOG("StateLayer Created");
}

StateLayer::~StateLayer()
{
	CCLOG("StateLayer Destoryed");
}

bool StateLayer::init()
{
	bool ret = false;

	do
	{
		CC_BREAK_IF(!Layer::init());

		auto touchListener = EventListenerTouchOneByOne::create();
		CC_BREAK_IF(!touchListener);
		touchListener->onTouchBegan = CC_CALLBACK_2(StateLayer::onTouchBegan, this);
		_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

		ret = true;

	} while (0);

	return ret;
}

bool StateLayer::onTouchBegan(cocos2d::Touch* touch, cocos2d::Event* event) 
{
	if (IsFly == false)
	{
		IsFly = true;
		UiLayer::IsTouch = true;
	}

	GetMainPlayer()->Jump();

	CCLOG("ontouchbegan");
    return true;
}