#include "GameWorld.h"
#include "UiLayer.h"
#include "StateLayer.h"
#include "define.h"

GameWorld* GameWorld::_gwinstance = nullptr;
float GameWorld::GameSpeed = 3.0f;
int GameWorld::GameHour = 8;


GameWorld::GameWorld()
{
	CCLOG("GameWorld Created");
	this->_uilayer = nullptr;

#if CC_TARGET_PLATFORM==CC_PLATFORM_WIN32||CC_TARGET_PLATFORM==CC_PLATFORM_LINUX
	struct tm _tm;
	time_t now;
	time(&now);
	if (localtime_s(&_tm, &now) == 0)
	{
		GameWorld::GameHour = _tm.tm_hour;
	}
	else
	{
		GameWorld::GameHour = 8;
	}
#elif CC_TARGET_PLATFORM==CC_PLATFORM_ANDROID||CC_TARGET_PLATFORM==CC_PLATFORM_IOS
	struct timeval now;
	struct tm* time;
	gettimeofday(&now, NULL);
	time = localtime(&now.tv_sec);
	GameWorld::GameHour = (int)time->tm_hour;
#endif
}

GameWorld::~GameWorld()
{
	CCLOG("GameWorld Destoryed");
}

bool GameWorld::init()
{
	bool ret = false;

	do
	{
		CC_BREAK_IF(!Scene::init());
		CC_BREAK_IF(!InitResources());

		_uilayer = UiLayer::create();
		CC_BREAK_IF(!_uilayer);

		_statelayer = StateLayer::create();
		CC_BREAK_IF(!_statelayer);

		this->addChild(_statelayer, 1);
		this->addChild(_uilayer, 0);
		
		ret = true;

	} while (0);

	return ret;
}

bool GameWorld::InitResources()
{
	bool ret = true;

	do
	{
		SpriteFrameCache::getInstance()->addSpriteFramesWithFile("images.plist");
		if (SpriteFrameCache::getInstance()->getSpriteFrameByName("bg_day.png") == nullptr)
			break;

		ret = true;
		
	} while (0);

	return ret;
}

void GameWorld::DeleteNode(Node* __node,bool __clearup)
{
	if (__node)
	{
		__node->stopAllActions();
		__node->removeFromParentAndCleanup(__clearup);
		__node = nullptr;
	}
	return;
}

void GameWorld::FillToWin(Node* __node)
{

}

void GameWorld::SetSprToCenter(Node* __node)
{
	if (__node)
	{
		__node->setPosition(GW::GetWinCenter());
	}
}

Vec2 GameWorld::GetWinCenter()
{
	return Vec2(DIN()->getWinSize().width / 2, DIN()->getWinSize().height / 2);
}

Vec2 GameWorld::GetWinMaxSize()
{
	return Vec2(DIN()->getWinSize());
}

GameWorld* GameWorld::GetGameWorld()
{
	if (GameWorld::_gwinstance == nullptr)
	{
		GameWorld::_gwinstance = GameWorld::create();

		if (!GameWorld::_gwinstance)
		{
			delete GameWorld::_gwinstance;
			return nullptr;
		}
	}

	return GameWorld::_gwinstance;
}
