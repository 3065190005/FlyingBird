#pragma once

#ifndef __DEFINE_H_
#define __DEFINE_H_

	#ifndef GW
		#define GW GameWorld
	#endif // !GW

	#ifndef GWIN
		#define GWIN GameWorld::GetGameWorld
	#endif // !GWIN


	#ifndef GWMP
		#define GWMP GameWorld::GetMainPlayer
	#endif // !GWMP

	#ifndef DIN
		#define DIN Director::getInstance
	#endif // !DIN

	#ifndef ccp
		#define ccp(var1,var2) Vec2(var1,var2)
	#endif // !ccp

	#ifndef GetMainPlayer
		#define GetMainPlayer  Player::PGetMainPlayer
		#define GMPL GetMainPlayer
	#endif // !GetMainPlayer


	#ifndef ANIMATETYPE
		#define ANIMATETYPE
		typedef int	AnimateType;
		#define YellowMode 0
		#define BlueMode 1
		#define RedMode 2

	#endif // !1

	#ifndef JG
		#define JG

		#define BGJG 4
		#define WALKJG 4
		#define BUILDJG 3
	#endif // !JG


	#ifndef BUILDSTRUCT
		#define BUILDSTRUCT
		typedef struct _buildstruct
		{
			class Build* _buildup;
			class Build* _builddown;
			bool _isOver = false;
		} BuildStruct;
	#endif // !BUILDSTRUCT

#endif

