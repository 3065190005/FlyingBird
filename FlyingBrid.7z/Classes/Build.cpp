#include "Build.h"
#include <define.h>
#include "GameWorld.h"

Build::Build()
{
	CCLOG("Build Created");
	this->_isaddscore = true;
}

Build::~Build()
{
	CCLOG("Build Destoryed");
}

bool Build::init()
{
	bool ret = false;

	do
	{
		if (GameWorld::GameHour <= 6 || GameWorld::GameHour >= 21)
		{
			CC_BREAK_IF(!Sprite::initWithSpriteFrameName("pipe2_up.png"));
		}
		else
		{
			CC_BREAK_IF(!Sprite::initWithSpriteFrameName("pipe_up.png"));
		}
		

		this->setAnchorPoint(ccp(this->getIsFilpx() == true ? 1.0f : 0.0f, 0.35f));
		this->setRotation(this->getIsFilpx() == true ? 180.0f: 0.0f);


		ret = true;

	} while (0);

	return ret;
}

bool Build::update()
{
	// ��������λ��
	if (this->getPositionX() < -DIN()->getWinSize().width / BUILDJG)
	{
		this->setPositionX(DIN()->getWinSize().width + DIN()->getWinSize().width / BUILDJG);
		return true;
	}
	else
	{
		this->setPositionX(this->getPositionX() - 0.1f);
		return false;
	}
}

void Build::RandomPosY(BuildStruct* __buildstruct, float _df)
{
	if (__buildstruct)
	{
		if (__buildstruct->_builddown && __buildstruct->_buildup)
		{
			float _temp = random(-_df, _df);
			__buildstruct->_builddown->setPositionY(0.0f);
			__buildstruct->_buildup->setPositionY(DIN()->getWinSize().height);

			__buildstruct->_builddown->setPositionY(__buildstruct->_builddown->getPositionY() + _temp);
			__buildstruct->_buildup->setPositionY(__buildstruct->_buildup->getPositionY() + _temp);
		}
	}
}

Build* Build::create(Vec2 __pos, bool __isfipx)
{
	Build* i = new Build();
	if(i)
		i->setIsFilpx(__isfipx);
	if (i && i->init())
	{
		i->autorelease();
		i->setPosition(__pos);
		return i;
	}
	else
	{
		delete i;
		i = nullptr;
		return nullptr;
	}
}
