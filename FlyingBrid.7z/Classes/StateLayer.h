#include "include.h"
#include "define.h"

class StateLayer : public Layer
{
public:
	StateLayer();
	~StateLayer();

	bool init() override;

	virtual bool onTouchBegan(cocos2d::Touch*, cocos2d::Event*);

	static bool IsFly;

	CC_SYNTHESIZE(bool, _touch, Touch);

	CREATE_FUNC(StateLayer);

};