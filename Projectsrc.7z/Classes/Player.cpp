#include "Player.h"

Player::Player()
{
	CCLOG("Player Created");
	this->_typeanimate = random(0, 2);
	this->_isdead = false;
	this->_isinit = false;
	this->_partical = nullptr;
	_t = 0.0f;
}

Player::~Player()
{
	CCLOG("Player Destoryed");
}

bool Player::init()
{
	bool ret = false;

	do
	{
		std::string _path;
		_path = std::string("bird") + std::to_string(_typeanimate) + "_0.png";
		CC_BREAK_IF(!Sprite::initWithSpriteFrameName(_path.c_str())) ;

		schedule(CC_CALLBACK_1(Player::updateTime, this),0.01f, "MyPlayerUpdateTime");
		scheduleUpdate();

		ret = true;
	} while (0);

	return ret;
}

void Player::updateTime(float df)
{
	if(this->_isinit == true)
			this->_t += 0.04f;
}

void Player::Jump()
{
	if (this->_isdead == false && this->_isinit == true)
	{
		this->_t = 0.0f;
		this->_v0 = 2.7f;
		this->_v = 0.0f;

		if (this->getActionByTag(1) != nullptr)
		{
			this->stopActionByTag(1);
		}

		AudioEngine::play2d("sfx_wing.mp3");

		this->setRotation(0.0f);
		auto* _action = Sequence::createWithTwoActions(RotateTo::create(0.15f, -25.0f), RotateTo::create(1.3f, 90.0f));
		_action->setTag(1);
		this->runAction(_action);
		ChangeAnimate();
	}
}

void Player::update(float df)
{

	// ������Чλ��
	if (GetMainPlayer() && this->_partical)
	{
		this->_partical->setPosition(GetMainPlayer()->getPosition());
	}

	if (this->_isinit == true && this->_isdead == false)
	{
		// ѭ������
		if (_v0 != 0.0f)
		{
			// ����
			this->_v = _v0 - _g * _t;
			this->setPositionY(this->getPositionY() + this->_v);

			if (this->_v <= 0.1f)
			{
				this->_v0 = 0.0f;
				this->_v = 0.0f;
				this->_t = 0.0f;
			}
		}
		else
		{
			// �´�
			this->_v = _g * _t;

			if (this->getPositionY() > -this->getContentSize().height * 3.0f)
				this->setPositionY(this->getPositionY() - this->_v);
			else
				this->setPositionY(-this->getContentSize().height * 3.0f);
		}
	}
}

void Player::ChangeAnimate()
{
	this->stopActionByTag(3);

	if (this->_isinit == false)
	{
	// δ��ʼ��Ϸ
		Animation* _i = Animation::create();

		std::string _name("bird");
		_name += std::to_string(this->_typeanimate);
		_name += "_";	
		for (int i = 0; i < 3; i++)
		{
			_i->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(std::string(_name + std::to_string(i) + std::string(".png")).c_str()));
		}
		for (int i = 2; i > -1; i--)
		{
			_i->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(std::string(_name + std::to_string(i) + std::string(".png")).c_str()));
		}
		_i->setDelayPerUnit(0.05f);
		_i->setRestoreOriginalFrame(true);

		auto _j = RepeatForever::create(Animate::create(_i));
		_j->setTag(3);

		this->runAction(_j);
	}
	else
	{
	// �ѿ�ʼ��Ϸ
		Animation* _i = Animation::create();

		std::string _name("bird");
		_name += std::to_string(this->_typeanimate);
		_name += "_";
		_i->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(std::string(_name + std::string("0") + std::string(".png")).c_str()));
		for (int i = 0; i < 3; i++)
		{
			_i->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(std::string(_name + std::to_string(i) + std::string(".png")).c_str()));
		}
		_i->setDelayPerUnit(0.05f);
		_i->setRestoreOriginalFrame(false);

		auto _j = Animate::create(_i);
		_j->setTag(3);

		this->runAction(_j);
	}
}

void Player::Dead()
{
	if (this->_isdead == false)
	{
		this->_isdead = true;
		this->stopAllActions();
		this->runAction(Spawn::createWithTwoActions(JumpTo::create(0.8f, Vec2(this->getPositionX(), -this->getContentSize().height * 3.0f), this->getContentSize().height*6.0f, 1), RotateTo::create(0.8f, -180.0f)));
	}
}

Player* Player::PGetMainPlayer()
{
	static Player* _mainplayer = nullptr;

	if (_mainplayer == nullptr)
	{
		_mainplayer = new Player();

		if (_mainplayer && _mainplayer->init())
		{
			_mainplayer->autorelease();
			return _mainplayer;
		}
		else
		{
			delete _mainplayer;
			_mainplayer = nullptr;
			return nullptr;
		}
	}
	else
	{
		return _mainplayer;
	}
}
