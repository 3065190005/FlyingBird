#pragma once
#include <include.h>
#include <define.h>
class Build : public Sprite
{
public:
	Build();
	~Build();

	bool init() override;
	bool update();						// ��ϵͳ�ص�

	static void RandomPosY(BuildStruct* __buildstruct, float _df = 50.0f);	//�������Build�ߵ�λ��

	
	static Build* create(Vec2 __pos = Vec2(0.0f, 0.0f),bool __isfipx = false);	// ����

	CC_SYNTHESIZE(bool, _isfilpx, IsFilpx);		// �Ƿ�ת
	CC_SYNTHESIZE(bool, _isaddscore, IsAddScore);		// �Ƿ�ת
};

